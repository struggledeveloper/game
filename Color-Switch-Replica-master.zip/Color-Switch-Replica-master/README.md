# Color Switch Replica
This is the source code for a Color Switch replica created during a Twitch livestream.

Everything is made using Unity.

Check out my [YouTube Channel](http://youtube.com/brackeys) for more tutorials. The livestream will be uploaded there as well.

Everything is free to use also commercially (public domain) except for the car sprite which I found on google.